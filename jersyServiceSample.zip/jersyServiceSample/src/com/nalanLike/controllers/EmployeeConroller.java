package com.nalanLike.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.codehaus.jettison.json.JSONObject;

import com.nalanLike.model.Employee;
import com.nalanLike.model.EmployeeDetails;
import com.nalanLike.model.EmployeeDetailscpy;
import com.nalanLike.model.LeaveDetails;
import com.nalanLike.service.EmployeeService;
import com.nalanLike.service.EmployeeServiceImpl;

@Path("/employee")
public class EmployeeConroller {

	EmployeeService nalanService = new EmployeeServiceImpl(); // creating a
																// instance for
																// the service

	@Path("/auth")
	@POST
	@Consumes("application/json")
	public String authUserByEmail(Employee check_employee) throws Exception {
		String email = check_employee.getEmail();
		String pwd = check_employee.getPassword();
		Employee employee = nalanService.findUserByEmail(email, pwd);

		String response = "";
		JSONObject jsonObject = new JSONObject();

		if (email.equalsIgnoreCase(employee.getEmail()) && pwd.equalsIgnoreCase(employee.getPassword())) {

			jsonObject.put("Status", "Success");
			jsonObject.put("name", employee.getUsername());
			jsonObject.put("email", employee.getEmail());
			jsonObject.put("uid", employee.getEmployee_id());
			jsonObject.put("role", employee.getRole());

			response = jsonObject.toString();

		} else {

			jsonObject.put("Status", "Failure");
			response = jsonObject.toString();
		}

		return response;
	}

	@Path("/getAllEmployeeDetails")
	@GET
	@Produces("application/json")
	public List<EmployeeDetails> getEmployeeDetails() {
		return nalanService.getEmployeeDetails();
	}

	@Path("/individualUserLogin")
	@GET
	@Produces("application/json")

	public List<EmployeeDetails> getIndividualUser(@QueryParam("userid") int id) {
		return nalanService.getIndividualUser(id);
	}

	@Path("/addUsers")
	@POST
	@Produces("application/json")

	public String saveUsers(Employee employee) {
		return nalanService.saveUsers(employee);
	}

	@Path("/editDetails")
	@POST
	@Produces("application/json")

	public String editDetails(EmployeeDetailscpy emplDetails) {
		return nalanService.editDetails(emplDetails);
	}

	@Path("/applyLeave")
	@POST
	@Produces("application/json")

	public String applyLeave(LeaveDetails leaveDetails) {
		return nalanService.applyLeave(leaveDetails);
	}

	@Path("/getUserAppliedLeave")
	@GET
	@Produces("application/json")

	public List<LeaveDetails> getUserAppliedLeave(@QueryParam("userid") int userid) {
		return nalanService.getUserAppliedLeave(userid);
	}

	@Path("/getAllLeave")
	@GET
	@Produces("application/json")

	public List<LeaveDetails> getAllLeave() {
		return nalanService.getAllLeave();
	}

	@Path("/approveLeave")
	@POST
	@Produces("application/json")

	public String approveLeave(LeaveDetails leaveDetails) {
		return nalanService.approveLeave(leaveDetails);
	}
	
	@Path("/getPendingLeave")
	@GET
	@Produces("application/json")
	
	public List<LeaveDetails> getPendingLeave(){
		return nalanService.getPendingLeave(); 
	}

}