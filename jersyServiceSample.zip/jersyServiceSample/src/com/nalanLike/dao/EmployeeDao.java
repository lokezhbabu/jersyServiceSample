package com.nalanLike.dao;

import java.util.List;

import com.nalanLike.model.Employee;
import com.nalanLike.model.EmployeeDetails;
import com.nalanLike.model.EmployeeDetailscpy;
import com.nalanLike.model.LeaveDetails;

public interface EmployeeDao {

	public String editDetails(EmployeeDetailscpy emplDetails);

	public List<EmployeeDetails> getEmployee();

	public List<EmployeeDetails> getUserdetails(int id);

	public String saveUsers(Employee employee);

	public Employee findUserByEmail(String email, String pwd);

	public String applyLeave(LeaveDetails leaveDetails);

	public List<LeaveDetails> getUserAppliedLeave(int userid);

	public List<LeaveDetails> getAllLeave();

	public String approveLeave(LeaveDetails leaveDetails);

	public List<LeaveDetails> getPendingLeave();
}
