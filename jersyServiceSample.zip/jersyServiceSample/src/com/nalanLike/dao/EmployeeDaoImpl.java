package com.nalanLike.dao;

import java.util.List;

import com.nalanLike.model.Employee;
import com.nalanLike.model.EmployeeDetails;
import com.nalanLike.model.EmployeeDetailscpy;
import com.nalanLike.model.LeaveDetails;
import com.nalanLike.util.HibernateUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	HibernateUtil hibernateUtil = new HibernateUtil();
	static String RESULT = "Success";

	@Override
	public List<EmployeeDetails> getEmployee() {
		hibernateUtil.openCurrentSession();
		@SuppressWarnings("unchecked")
		List<EmployeeDetails> empl_records = (List<EmployeeDetails>) hibernateUtil.getCurrentSession()
				.createQuery("from EmployeeDetails").list();
		hibernateUtil.closeCurrentSession();
		return empl_records;
	}

	@Override
	public List<EmployeeDetails> getUserdetails(int id) {
		hibernateUtil.openCurrentSession();
		@SuppressWarnings("unchecked")
		List<EmployeeDetails> empl_records = (List<EmployeeDetails>) hibernateUtil.getCurrentSession()
				.createQuery("from EmployeeDetails where details_id='" + id + "' ").list();
		hibernateUtil.closeCurrentSession();
		return empl_records;
	}

	@Override
	public String saveUsers(Employee employee) {
		hibernateUtil.openCurrentSessionwithTransaction();
		hibernateUtil.getCurrentSession().save(employee);
		EmployeeDetails employee_details = new EmployeeDetails();
		employee_details.setEmpl(employee);
		hibernateUtil.getCurrentSession().save(employee_details);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return RESULT;
	}

	@Override
	public String editDetails(EmployeeDetailscpy emplDetails) {
		hibernateUtil.openCurrentSessionwithTransaction();
		hibernateUtil.getCurrentSession().update(emplDetails);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return RESULT;
	}

	@Override
	public Employee findUserByEmail(String email, String pwd) {
		hibernateUtil.openCurrentSession();
		Employee employee = (Employee) hibernateUtil.getCurrentSession()
				.createQuery("from Employee where email='" + email + "' and password='" + pwd + "' ").uniqueResult();
		hibernateUtil.closeCurrentSession();
		return employee;
	}

	@Override
	public String applyLeave(LeaveDetails leaveDetails) {
		hibernateUtil.openCurrentSessionwithTransaction();
		hibernateUtil.getCurrentSession().save(leaveDetails);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return RESULT;
	}

	@Override
	public List<LeaveDetails> getUserAppliedLeave(int userid) {
		hibernateUtil.openCurrentSession();
		@SuppressWarnings("unchecked")
		List<LeaveDetails> empl_leave = (List<LeaveDetails>) hibernateUtil.getCurrentSession()
				.createQuery(" from LeaveDetails where employee_id='" + userid + "' ").list();
		hibernateUtil.closeCurrentSession();
		return empl_leave;

	}

	@Override
	public List<LeaveDetails> getAllLeave() {
		hibernateUtil.openCurrentSession();
		@SuppressWarnings("unchecked")
		List<LeaveDetails> leave_records = (List<LeaveDetails>) hibernateUtil.getCurrentSession()
				.createQuery(" from LeaveDetails").list();
		hibernateUtil.closeCurrentSession();
		return leave_records;
	}

	@Override
	public String approveLeave(LeaveDetails leaveDetails) {
		hibernateUtil.openCurrentSessionwithTransaction();
		hibernateUtil.getCurrentSession().update(leaveDetails);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return RESULT;
	}

	@Override
	public List<LeaveDetails> getPendingLeave() {
		hibernateUtil.openCurrentSession();
		@SuppressWarnings("unchecked")
		List<LeaveDetails> pendingLeave_records = (List<LeaveDetails>) hibernateUtil.getCurrentSession()
				.createQuery(" from LeaveDetails where status = 0").list();
		hibernateUtil.closeCurrentSession();
 		return pendingLeave_records;
	}

}
