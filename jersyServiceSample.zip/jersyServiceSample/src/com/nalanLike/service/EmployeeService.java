package com.nalanLike.service;

import java.util.List;

import com.nalanLike.model.Employee;
import com.nalanLike.model.EmployeeDetails;
import com.nalanLike.model.EmployeeDetailscpy;
import com.nalanLike.model.LeaveDetails;

public interface EmployeeService {

	public List<EmployeeDetails> getEmployeeDetails();

	public List<EmployeeDetails> getIndividualUser(int id);

	public String saveUsers(Employee employee);

	public String editDetails(EmployeeDetailscpy emplDetails);

	public Employee findUserByEmail(String email, String pwd);

	public String applyLeave(LeaveDetails leaveDetails);

	public List<LeaveDetails> getUserAppliedLeave(int userid);

	public List<LeaveDetails> getAllLeave();

	public String approveLeave(LeaveDetails leaveDetails);

	public List<LeaveDetails> getPendingLeave();
}
