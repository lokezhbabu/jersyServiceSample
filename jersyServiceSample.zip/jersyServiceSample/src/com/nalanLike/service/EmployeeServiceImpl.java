package com.nalanLike.service;

import java.util.List;

import com.nalanLike.dao.EmployeeDao;
import com.nalanLike.dao.EmployeeDaoImpl;
import com.nalanLike.model.Employee;
import com.nalanLike.model.EmployeeDetails;
import com.nalanLike.model.EmployeeDetailscpy;
import com.nalanLike.model.LeaveDetails;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao nalanDao = new EmployeeDaoImpl();
	

	@Override
	public List<EmployeeDetails> getEmployeeDetails() {
		
		return nalanDao.getEmployee();
	}

	@Override
	public List<EmployeeDetails> getIndividualUser(int id) {
		return nalanDao.getUserdetails(id);
		
	}

	@Override
	public String saveUsers(Employee employee) {
		
		return nalanDao.saveUsers(employee);
	}

	@Override
	public String editDetails(EmployeeDetailscpy  emplDetails) {
		
		return nalanDao.editDetails(emplDetails);
	}

	@Override
	public Employee findUserByEmail(String email, String pwd) {
		return nalanDao.findUserByEmail(email, pwd);
	}

	@Override
	public String applyLeave(LeaveDetails leaveDetails) {
		
		return nalanDao.applyLeave(leaveDetails);
	}

	@Override
	public List<LeaveDetails> getUserAppliedLeave(int userid) {
		
		return nalanDao.getUserAppliedLeave(userid);
	}

	@Override
	public List<LeaveDetails> getAllLeave() {
		
		return nalanDao.getAllLeave();
	}

	@Override
	public String approveLeave(LeaveDetails leaveDetails) {

		return nalanDao.approveLeave(leaveDetails);
	}

	@Override
	public List<LeaveDetails> getPendingLeave() {
		
		return nalanDao.getPendingLeave();
	}
}
